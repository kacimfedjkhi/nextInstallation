export const ROUTES = {
  home: `/`,
  onboarding: `/onboarding`,
  write: `/write`,
  open: `/open`,
  detail: `/detail`,
  admin: `/admin`,
  setup: `/setup`,
  sent: `/sent`
};

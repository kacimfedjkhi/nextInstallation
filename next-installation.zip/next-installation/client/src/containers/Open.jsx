import React from "react";
import CardsCollection from "../components/CardsCollection";
// import { Link } from "react-router-dom";
// import { ROUTES } from "../constants";
// import Button from "@material-ui/core/Button";

const Open = () => {
  return (
    <>
      <h1>Pick a card to open</h1>
      
      <CardsCollection />
    </>
  );
};

export default Open;
